#include "Rasterizer.h"

void Rasterizer::BuildPolyline() {

	float du = TexelSize * 0.25f;

	for (auto& curve : Curves) {
		const std::vector<glm::vec3>& cp = curve.ControlPoints;
		const int LoopCount = (int)(cp.size() - 1) / 3;

		bool FirstPoint = true;

		float accumulator = 0.0f;
		glm::vec3 PrePos = cp[0];
		for (int i = 0; i < LoopCount; i++) {
			// �� ���׸�Ʈ���� 4 ���� ��, 3n ~ 3n + 3
			const glm::vec3 p0 = cp[3 * i];
			const glm::vec3 p1 = cp[3 * i + 1];
			const glm::vec3 p2 = cp[3 * i + 2];
			const glm::vec3 p3 = cp[3 * i + 3];

			for (float j = 0.0f; j < 1.0f; j += du) {
				if (FirstPoint) {
					const LinearCoord lc = CreateLinearCoord(p0, p1, p2, p3, j);
					curve.PolylineSamples.emplace_back(lc);
					PrePos = lc.Pos;
					FirstPoint = false;
					continue;
				}
				
				glm::vec3 pos = BezierCubic(p0, p1, p2, p3, j);
				
				accumulator += glm::length(pos - PrePos);
				if (accumulator >= TexelSize) {
					curve.PolylineSamples.emplace_back(CreateLinearCoord(p0, p1, p2, p3, j));
					accumulator -= TexelSize;
				}
				PrePos = pos;
			}

			curve.PolylineSamples.emplace_back(CreateLinearCoord(p0, p1, p2, p3, 1.0f));
		}
	}

}

const LinearCoord Rasterizer::CreateLinearCoord(const glm::vec3& p0, const glm::vec3& p1, const glm::vec3& p2, const glm::vec3& p3, float t) {
	
	float u = 1.0f - t;
	glm::vec3 pos = u * u * u * p0 + 3.0f * u * u * t * p1 + 3.0f * u * t * t * p2 + t * t * t * p3;

	glm::vec3 PreviousTangent = glm::vec3(0.0f);
	glm::vec3 tangent = glm::normalize(3.0f * u * u * (p1 - p0) + 6.0f * u * t * (p2 - p1) + 3.0f * t * t * (p3 - p2));
	if (glm::length(tangent) < 1e-8f) tangent = PreviousTangent;
	else PreviousTangent = tangent;
	// +normal ���� = left
	// constraint�� a ����
	glm::vec3 normal = glm::normalize(glm::vec3(tangent.z, 0.0f, -tangent.x));

	return LinearCoord{ pos, normal, tangent, glm::clamp(t, 0.0f, 1.0f) };

}

void Rasterizer::PrintPolylines() const {
	int count = 0;
	for (const auto& curve : Curves) {
		count += curve.PolylineSamples.size();
		printf("Polyline Samples:\n");
		for (const auto& sample : curve.PolylineSamples) {
			printf("Pos: (%.3f, %.3f, %.3f), Normal: (%.3f, %.3f, %.3f), Tangent: (%.3f, %.3f, %.3f), u: %.3f\n",
				sample.Pos.x, sample.Pos.y, sample.Pos.z,
				sample.Normal.x, sample.Normal.y, sample.Normal.z,
				sample.Tangent.x, sample.Tangent.y, sample.Tangent.z,
				sample.u);
		}
		printf("\n");
	}
	std::cout << "Total Polyline Samples: " << count << std::endl;
}

void Rasterizer::PrintPolylineMasks() const {
	for (const auto& curve : Curves) {
		for (const auto& sample : curve.PolylineSamples) {
			if (HasMask(sample.Constraint.Mask, ConstraintMask::Elevation) || HasMask(sample.Constraint.Mask, ConstraintMask::Gradient)) std::cout << "HasMask" << std::endl;
		}
	}
}

float Rasterizer::InterpolateCubic(float p0, float p1, float p2, float p3, float t) {

	float t2 = t * t;
	float t3 = t2 * t;

	return 0.5f * (
		(2.0f * p1) +
		(-p0 + p2) * t +
		(2.0f * p0 - 5.0f * p1 + 4.0f * p2 - p3) * t2 +
		(-p0 + 3.0f * p1 - 3.0f * p2 + p3) * t3
		);

}

// constraint point -> sample point(poly line)
// ��Ģ
// Ŀ�� �� �� ���� u== 0.0/1.0������ Ŀ�� �� �� constraint point�� constraint�� �״�� ���(���� ���X)
// ������ ���� constraint point�� ��� �ش� constraint�� ���� ������ ����
// 
// h - cubic interpolation
// 2���� ���� ã�� ��� - endpoint clamping -> cubic interpolation
// 3���� ���� ã�� ��� - 2�� + 2��(1��->endpoint clamping) -> cubic interpolation
// 4���� ���� ã�� ��� - 4���� ������ cubic interpolation

void Rasterizer::InterpolateConstraints(CurveData& Curve) {

	for (auto& point : Curve.PolylineSamples) {

		point.Constraint.Mask = ConstraintMask::None;

		if ((point.u - 0.0f) < 1e-6f){
			point.Constraint = Curve.ConstraintPoints.front();
			point.Constraint.u = point.u;
			continue;
		}
		if ((point.u - 1.0f) < 1e-6f) {
			point.Constraint = Curve.ConstraintPoints.back();
			point.Constraint.u = point.u;
			continue;
		}

		int Segment = -1;
		for (int i = 0; i < Curve.ConstraintPoints.size() - 1; i++) {
			if (point.u >= Curve.ConstraintPoints[i].u && point.u <= Curve.ConstraintPoints[i + 1].u) {
				Segment = i;
				break;
			}
		}

		if (Segment == -1) continue;
		if (point.u - Curve.ConstraintPoints[Segment].u < 1e-6f) {
			point.Constraint = Curve.ConstraintPoints[Segment];
			point.Constraint.u = point.u;
			continue;
		}
		if (point.u - Curve.ConstraintPoints[Segment + 1].u > -1e-6f) {
			point.Constraint = Curve.ConstraintPoints[Segment + 1];
			point.Constraint.u = point.u;
			continue;
		}

		float t = (point.u - Curve.ConstraintPoints[Segment].u) / (Curve.ConstraintPoints[Segment + 1].u - Curve.ConstraintPoints[Segment].u);
		t = glm::clamp(t, 0.0f, 1.0f);

		if (HasMask(Curve.ConstraintPoints[Segment].Mask, ConstraintMask::Elevation) && HasMask(Curve.ConstraintPoints[Segment + 1].Mask, ConstraintMask::Elevation)) {
			float p0h, p1h, p2h, p3h;
			p1h = Curve.ConstraintPoints[Segment].h;
			p2h = Curve.ConstraintPoints[Segment + 1].h;
			p0h = (Segment > 0) ? Curve.ConstraintPoints[Segment - 1].h : Curve.ConstraintPoints[Segment].h;
			p3h = (Segment + 2 < Curve.ConstraintPoints.size()) ? Curve.ConstraintPoints[Segment + 2].h : Curve.ConstraintPoints[Segment + 1].h;

			point.Constraint.h = InterpolateCubic(p0h, p1h, p2h, p3h, t);
			point.Constraint.r = Lerp(Curve.ConstraintPoints[Segment].r, Curve.ConstraintPoints[Segment + 1].r, t);

			point.Constraint.Mask |= ConstraintMask::Elevation;
		}

		if (HasMask(Curve.ConstraintPoints[Segment].Mask, ConstraintMask::Gradient) && HasMask(Curve.ConstraintPoints[Segment + 1].Mask, ConstraintMask::Gradient)) {
			point.Constraint.a = Lerp(Curve.ConstraintPoints[Segment].a, Curve.ConstraintPoints[Segment + 1].a, t);
			point.Constraint.b = Lerp(Curve.ConstraintPoints[Segment].b, Curve.ConstraintPoints[Segment + 1].b, t);
			point.Constraint.theta = Lerp(Curve.ConstraintPoints[Segment].theta, Curve.ConstraintPoints[Segment + 1].theta, t);
			point.Constraint.phi = Lerp(Curve.ConstraintPoints[Segment].phi, Curve.ConstraintPoints[Segment + 1].phi, t);

			point.Constraint.Mask |= ConstraintMask::Gradient;
		}

		if (HasMask(Curve.ConstraintPoints[Segment].Mask, ConstraintMask::Noise) && HasMask(Curve.ConstraintPoints[Segment + 1].Mask, ConstraintMask::Noise)) {
			point.Constraint.Amplitude = Lerp(Curve.ConstraintPoints[Segment].Amplitude, Curve.ConstraintPoints[Segment + 1].Amplitude, t);
			point.Constraint.Roughness = Lerp(Curve.ConstraintPoints[Segment].Roughness, Curve.ConstraintPoints[Segment + 1].Roughness, t);

			point.Constraint.Mask |= ConstraintMask::Noise;
		}
		
		point.Constraint.u = point.u;
	}

}

void Rasterizer::InterpolateCurves() {
	for (auto& curve : Curves) {
		InterpolateConstraints(curve);
	}
}

bool Rasterizer::BuildQuad(const LinearCoord& p0, const LinearCoord& p1, Quad& OutQuad) {
	QuadVertex v0, v1, v2, v3;

	float LeftWidthP0 = 0.0f;
	float LeftWidthP1 = 0.0f;
	float RightWidthP0 = 0.0f;
	float RightWidthP1 = 0.0f;

	bool HasElevation = HasMask(p0.Constraint.Mask, ConstraintMask::Elevation) && HasMask(p1.Constraint.Mask, ConstraintMask::Elevation);
	bool HasGradient = HasMask(p0.Constraint.Mask, ConstraintMask::Gradient) && HasMask(p1.Constraint.Mask, ConstraintMask::Gradient);
	bool HasNoise = HasMask(p0.Constraint.Mask, ConstraintMask::Noise) && HasMask(p1.Constraint.Mask, ConstraintMask::Noise);

	if (!HasElevation && !HasGradient) return false;

	if (HasElevation && HasGradient) {
		LeftWidthP0 = std::max(p0.Constraint.a, p0.Constraint.r);
		LeftWidthP1 = std::max(p1.Constraint.a, p1.Constraint.r);
		RightWidthP0 = std::max(p0.Constraint.b, p0.Constraint.r);
		RightWidthP1 = std::max(p1.Constraint.b, p1.Constraint.r);
	}
	else if (HasElevation) {
		LeftWidthP0 = RightWidthP0 = p0.Constraint.r;
		LeftWidthP1 = RightWidthP1 = p1.Constraint.r;
	}
	else {
		LeftWidthP0 = p0.Constraint.a;
		LeftWidthP1 = p1.Constraint.a;
		RightWidthP0 = p0.Constraint.b;
		RightWidthP1 = p1.Constraint.b;
	}

	v0.Position = p0.Pos + p0.Normal * LeftWidthP0;
	v0.Constraint = p0.Constraint;
	v0.CurvePos = p0.Pos;
	v0.CurveNormal = p0.Normal;
	v1.Position = p1.Pos + p1.Normal * LeftWidthP1;
	v1.Constraint = p1.Constraint;
	v1.CurvePos = p1.Pos;
	v1.CurveNormal = p1.Normal;
	
	v2.Position = p0.Pos - p0.Normal * RightWidthP0;
	v2.Constraint = p0.Constraint;
	v2.CurvePos = p0.Pos;
	v2.CurveNormal = p0.Normal;
	v3.Position = p1.Pos - p1.Normal * RightWidthP1;
	v3.Constraint = p1.Constraint;
	v3.CurvePos = p1.Pos;
	v3.CurveNormal = p1.Normal;


	OutQuad.V0 = v0;
	OutQuad.V1 = v1;
	OutQuad.V2 = v3;
	OutQuad.V3 = v2;

	OutQuad.HasElevation = HasElevation;
	OutQuad.HasGradient = HasGradient;
	OutQuad.HasNoise = HasNoise;

	return true;

}

void Rasterizer::BuildQuads() {
	Quad quad;

	for (const auto& curve : Curves) {
		for (int i = 0; i < curve.PolylineSamples.size() - 1; i++) {
			if (BuildQuad(curve.PolylineSamples[i], curve.PolylineSamples[i + 1], quad)) Quads.emplace_back(quad);
			//else std::cout << "false" << std::endl;
		}
	}

}

void Rasterizer::PrintQuads() const{

	std::cout << "Quad count: " << Quads.size() << std::endl;
	for (const auto& quad : Quads) {
		std::cout << "Quad Vertices :" << "[V0 : (" << quad.V0.Position.x << ", " << quad.V0.Position.y << ", " << quad.V0.Position.z << "), "
			<< "V1 : (" << quad.V1.Position.x << ", " << quad.V1.Position.y << ", " << quad.V1.Position.z << "), "
			<< "V2 : (" << quad.V2.Position.x << ", " << quad.V2.Position.y << ", " << quad.V2.Position.z << "), "
			<< "V3 : (" << quad.V3.Position.x << ", " << quad.V3.Position.y << ", " << quad.V3.Position.z << ")]" << std::endl;
	}

}

void Rasterizer::BuildConstraintMaps() {

	for(const auto& quad : Quads) {

		int MinC, MinR, MaxC, MaxR;

		AABB aabb = ComputeAABB(quad.V0.Position, quad.V1.Position, quad.V2.Position, quad.V3.Position);

		MinC = floor(aabb.Min.x * (Width - 1));
		MaxC = ceil(aabb.Max.x * (Width - 1));
		MinR = floor(aabb.Min.y * (Height - 1)); // vec2�� y���� �����δ� z��ǥ��
		MaxR = ceil(aabb.Max.y * (Height - 1));

		MinC = glm::clamp(MinC, 0, Width - 1);
		MaxC = glm::clamp(MaxC, 0, Width - 1);
		MinR = glm::clamp(MinR, 0, Height - 1);
		MaxR = glm::clamp(MaxR, 0, Height - 1);

		for (int r = MinR; r <= MaxR; r++) {
			for (int c = MinC; c <= MaxC; c++) {
				glm::vec2 Pos = glm::vec2((float)c / (float)(Width - 1), (float)r / (float)(Height - 1));

				InterpolateQuad(Pos, quad, r, c);

			}
		}


	}

}

AABB Rasterizer::ComputeAABB(const glm::vec3& v0, const glm::vec3& v1, const glm::vec3 v2, const glm::vec3 v3) const {
	float MinX = std::min(std::min(v0.x, v1.x), std::min(v2.x, v3.x));
	float MaxX = std::max(std::max(v0.x, v1.x), std::max(v2.x, v3.x));
	float MinZ = std::min(std::min(v0.z, v1.z), std::min(v2.z, v3.z));
	float MaxZ = std::max(std::max(v0.z, v1.z), std::max(v2.z, v3.z));

	return AABB{ glm::vec2(MinX, MinZ), glm::vec2(MaxX, MaxZ) };
}

bool Rasterizer::Barycentric(const glm::vec2& p, const glm::vec2& a, const glm::vec2& b, const glm::vec2& c, float& OutU, float& OutV, float& OutW) const {

	glm::vec2 v0 = b - a;
	glm::vec2 v1 = c - a;
	glm::vec2 v2 = p - a;

	float d00 = glm::dot(v0, v0);
	float d01 = glm::dot(v0, v1);
	float d11 = glm::dot(v1, v1);
	float d20 = glm::dot(v2, v0);
	float d21 = glm::dot(v2, v1);

	float denom = d00 * d11 - d01 * d01;
	if (abs(denom) < 1e-8f) return false;

	float v = (d11 * d20 - d01 * d21) / denom;
	float w = (d00 * d21 - d01 * d20) / denom;
	float u = 1.0f - v - w;

	OutU = u;
	OutV = v;
	OutW = w;

	return (u >= 0) && (v >= 0) && (w >= 0);



}

void Rasterizer::InterpolateQuad(const glm::vec2& p, const Quad& quad, int row, int col) {

	QuadVertex V0, V1, V2;

	float u, v, w;

	int index = row * Width + col;

	if (Barycentric(p, glm::vec2(quad.V0.Position.x, quad.V0.Position.z),
		glm::vec2(quad.V1.Position.x, quad.V1.Position.z),
		glm::vec2(quad.V2.Position.x, quad.V2.Position.z),
		u, v, w)) {
		V0 = quad.V0;
		V1 = quad.V1;
		V2 = quad.V2;
	}
	else if (Barycentric(p, glm::vec2(quad.V0.Position.x, quad.V0.Position.z),
		glm::vec2(quad.V2.Position.x, quad.V2.Position.z),
		glm::vec2(quad.V3.Position.x, quad.V3.Position.z),
		u, v, w)) {
		V0 = quad.V0;
		V1 = quad.V2;
		V2 = quad.V3;
	}
	else return;

	glm::vec3 InterpolatedCurvePos = u * V0.CurvePos + v * V1.CurvePos + w * V2.CurvePos;
	glm::vec3 InterpolatedCurveNormal = glm::normalize(u * V0.CurveNormal + v * V1.CurveNormal + w * V2.CurveNormal);

	float r = u * V0.Constraint.r + v * V1.Constraint.r + w * V2.Constraint.r;
	float a = u * V0.Constraint.a + v * V1.Constraint.a + w * V2.Constraint.a;
	float b = u * V0.Constraint.b + v * V1.Constraint.b + w * V2.Constraint.b;
	float h = u * V0.Constraint.h + v * V1.Constraint.h + w * V2.Constraint.h;
	float theta = u * V0.Constraint.theta + v * V1.Constraint.theta + w * V2.Constraint.theta;
	float phi = u * V0.Constraint.phi + v * V1.Constraint.phi + w * V2.Constraint.phi;
	float Amplitude = u * V0.Constraint.Amplitude + v * V1.Constraint.Amplitude + w * V2.Constraint.Amplitude;
	float Roughness = u * V0.Constraint.Roughness + v * V1.Constraint.Roughness + w * V2.Constraint.Roughness;

	float d = glm::dot(glm::vec2(p.x - InterpolatedCurvePos.x, p.y - InterpolatedCurvePos.z),
		glm::vec2(InterpolatedCurveNormal.x, InterpolatedCurveNormal.z));
	float ad = abs(d);

	bool ApplyElevation = false;
	bool ApplyGradientA = false;
	bool ApplyGradientB = false;

	// ��Ÿ��, �켱���� : Elevation > Gradient, r ���ο����� gradient�� ������� ����
	if (quad.HasElevation && (ad <= r)) ApplyElevation = true;
	else if (quad.HasGradient && (d > 0) && (ad <= a)) ApplyGradientA = true;
	else if (quad.HasGradient && (d < 0) && (ad <= b)) ApplyGradientB = true;

	if (ApplyElevation) {
		Map.ElevationMap[index] = std::max(Map.ElevationMap[index], h);
		Map.ConstraintMaskMap[index] |= (int)ConstraintMask::Elevation;
	}
	if (ApplyGradientA || ApplyGradientB) {
		if (Map.ConstraintMaskMap[index] & (int)ConstraintMask::Gradient){
			Map.ConstraintMaskMap[index] &= ~(int)ConstraintMask::Gradient;
			Map.GradientMap[index] = glm::vec2(0.0f, 0.0f);
			Map.Gradients[index] = glm::vec3(0.0f, 0.0f, 0.0f);
		}
		else {
			glm::vec2 n = glm::normalize(glm::vec2(InterpolatedCurveNormal.x, InterpolatedCurveNormal.z));
			if (ApplyGradientA) {
				Map.GradientMap[index] = glm::vec2(theta, phi);
				Map.ConstraintMaskMap[index] |= (int)ConstraintMask::Gradient;
				Map.Gradients[index].x = n.x;
				Map.Gradients[index].y = n.y;
				Map.Gradients[index].z = glm::tan(glm::radians(theta)); // == norm
			}
			else if (ApplyGradientB) {
				Map.GradientMap[index] = glm::vec2(theta, phi);
				Map.ConstraintMaskMap[index] |= (int)ConstraintMask::Gradient;
				Map.Gradients[index].x = -n.x;
				Map.Gradients[index].y = -n.y;
				Map.Gradients[index].z = glm::tan(glm::radians(phi));
			}

		}
	}
	if (quad.HasNoise) {
		Map.NoiseMap[index].x = std::max(Map.NoiseMap[index].x, Amplitude);
		Map.NoiseMap[index].y = std::max(Map.NoiseMap[index].y, Roughness);
		Map.ConstraintMaskMap[index] |= (int)ConstraintMask::Noise;
	}

}